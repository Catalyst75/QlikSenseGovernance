    .factory('dataLineageFactory',[function($resource,CONFIG) {          

            var lineage = {};

            	lineage={'test':1};

                return lineage;

    }])   


   
;
